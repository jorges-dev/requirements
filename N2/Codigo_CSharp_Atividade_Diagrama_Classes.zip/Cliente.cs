using System.Collections.Generic;

public class Cliente : Pessoa
{
    public string Telefone { get; private set; }

    private readonly List<Pedido> _pedidos = new();

    public IReadOnlyList<Pedido> Pedidos => _pedidos;

    public Cliente(string nome, string email, string telefone)
        : base(nome, email)
    {
        Telefone = telefone;
    }

    public void AtualizarTelefone(string novoTelefone)
    {
        Telefone = novoTelefone;
    }

    public void RegistrarPedido(Pedido pedido)
    {
        _pedidos.Add(pedido);
    }

    public override string ObterResumo()
    {
        return $"{Nome} - {Telefone}";
    }
}
