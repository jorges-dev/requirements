using System.Collections.Generic;

public class Funcionario : Pessoa
{
    public string Cargo { get; private set; }

    private readonly List<Pedido> _pedidosAtendidos = new();

    public IReadOnlyList<Pedido> PedidosAtendidos => _pedidosAtendidos;

    public Funcionario(string nome, string email, string cargo)
        : base(nome, email)
    {
        Cargo = cargo;
    }

    public void AlterarCargo(string novoCargo)
    {
        Cargo = novoCargo;
    }

    public void RegistrarAtendimento(Pedido pedido)
    {
        _pedidosAtendidos.Add(pedido);
    }

    public override string ObterResumo()
    {
        return $"{Nome} - {Cargo}";
    }
}
