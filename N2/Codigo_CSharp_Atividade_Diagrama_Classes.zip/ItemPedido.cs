using System;

public class ItemPedido
{
    public Produto Produto { get; }
    public int Quantidade { get; }
    public decimal PrecoUnitario { get; }

    public ItemPedido(Produto produto, int quantidade)
    {
        if (quantidade <= 0)
        {
            throw new ArgumentException("Quantidade inválida.");
        }

        Produto = produto;
        Quantidade = quantidade;
        PrecoUnitario = produto.Preco;
    }

    public decimal CalcularSubtotal()
    {
        return PrecoUnitario * Quantidade;
    }
}
