using System;
using System.Collections.Generic;

public class Pedido
{
    public int Numero { get; }
    public DateTime Data { get; }
    public Cliente Cliente { get; }
    public Funcionario Atendente { get; }

    private readonly List<ItemPedido> _itens = new();

    public IReadOnlyList<ItemPedido> Itens => _itens;

    public Pedido(int numero, Cliente cliente, Funcionario atendente)
    {
        Numero = numero;
        Data = DateTime.Now;
        Cliente = cliente;
        Atendente = atendente;

        cliente.RegistrarPedido(this);
        atendente.RegistrarAtendimento(this);
    }

    public void AdicionarItem(Produto produto, int quantidade)
    {
        produto.BaixarEstoque(quantidade);

        var item = new ItemPedido(produto, quantidade);
        _itens.Add(item);
    }

    public decimal CalcularTotal()
    {
        decimal total = 0;

        foreach (var item in _itens)
        {
            total += item.CalcularSubtotal();
        }

        return total;
    }
}
