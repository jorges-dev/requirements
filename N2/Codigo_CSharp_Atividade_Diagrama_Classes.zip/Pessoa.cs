using System;

public abstract class Pessoa
{
    public string Nome { get; private set; }
    public string Email { get; private set; }
    protected DateTime DataCadastro { get; }

    protected Pessoa(string nome, string email)
    {
        Nome = nome;
        Email = email;
        DataCadastro = DateTime.Now;
    }

    public void AtualizarEmail(string novoEmail)
    {
        Email = novoEmail;
    }

    public abstract string ObterResumo();
}
