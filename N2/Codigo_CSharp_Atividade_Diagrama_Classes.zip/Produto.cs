using System;

public class Produto
{
    public int Id { get; }
    public string Nome { get; private set; }
    public decimal Preco { get; private set; }
    public int Estoque { get; private set; }

    public Produto(int id, string nome, decimal preco, int estoque)
    {
        Id = id;
        Nome = nome;
        Preco = preco;
        Estoque = estoque;
    }

    public void AlterarPreco(decimal novoPreco)
    {
        if (novoPreco < 0)
        {
            throw new ArgumentException("Preço inválido.");
        }

        Preco = novoPreco;
    }

    public void BaixarEstoque(int quantidade)
    {
        if (quantidade <= 0 || quantidade > Estoque)
        {
            throw new ArgumentException("Quantidade inválida.");
        }

        Estoque -= quantidade;
    }

    public decimal CalcularSubtotal(int quantidade)
    {
        return Preco * quantidade;
    }
}
